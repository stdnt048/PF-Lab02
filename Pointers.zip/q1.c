#include<stdio.h>



int main()
{
    int age ;
    float cgpa ;
    char grade ; 
    int *age_ptr ;
    float *cgpa_ptr ; 
    char *grade_ptr ;
    
    printf("Enter Age : ");
    scanf("%d" , &age);
    printf("Enter CGPA : ");
    scanf("%f" , &cgpa);
    printf("Enter Grade : ");
    scanf(" %c" , &grade);
    
    age_ptr = &age ;
    cgpa_ptr = &cgpa ; 
    grade_ptr = &grade ;
    
    printf("age = %d , via pointer = %d , address = %p , adress via pointer = %p \n", age , *age_ptr , &age , age_ptr );
    printf("cgpa = %f , via pointer = %f , address = %p , adress via pointer = %p \n" , cgpa , *cgpa_ptr , &cgpa , cgpa_ptr);
    printf("grade = %c , via pointer = %c , address = %p , adress via pointer = %p \n", grade , *grade_ptr , &grade , grade_ptr);
    
    // it changes because we are changing the value at the address that is assigned to the pointer . 
  
  return 0;
}
