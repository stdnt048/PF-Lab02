#include<stdio.h>

void swap(int* , int*);
void sortThree(int* , int* , int*);

int main()
{
	int a , b , c ;
	int *a_ptr, *b_ptr , *c_ptr ;
	
	printf("Enter three numbers :");
	scanf("%d %d %d", &a , &b , &c );
	
	a_ptr = &a ;
	b_ptr = &b ;
	c_ptr = &c ;
	
	printf("Before : %d  %d  %d \n",a,b,c);
	
	sortThree(a_ptr , b_ptr , c_ptr);
	
	printf("After : %d  %d  %d \n",a,b,c);
	
	return 0;
}

void swap(int *x , int *y)
{
	int a ;
	a = *x ;
	*x = *y ;
	*y = a ;
}

void sortThree(int *a_ptr , int *b_ptr , int *c_ptr)
{
	if(*a_ptr > *b_ptr)
	swap(a_ptr,b_ptr);
	
	if(*a_ptr > *c_ptr)
	swap(a_ptr,c_ptr);
	
	if(*b_ptr > *c_ptr)
	swap(b_ptr,c_ptr);
	
	
}





