#include<stdio.h>

void showBalance(float *balance_ptr) ;
void deposit(float *balance_ptr , float amount) ;
int withdraw(float *balance_ptr , float amount) ;

int main()
{
  int choice , balance_return ;
  float amount , balance = 5000 ; 
  float *balance_ptr  ; 
  
  balance_ptr = &balance ;
  
  do{
    printf(" 1.Balance \n 2.Deposit \n 3.Withdraw \n 4.Exit \n");
    scanf("%d", &choice);
    
    if(choice == 1 )
    {
      showBalance( balance_ptr ) ;
    }
    else if(choice == 2 )
    {
      printf("Amount : ");
      scanf("%f" , &amount );
      if( amount <= 0 )
      printf("Invalid amount entered . \n");
      else
      deposit( balance_ptr , amount ) ;
    }
    else if(choice == 3 )
    {
      printf("Amount : ");
      scanf("%f" , &amount );
      balance_return = withdraw( balance_ptr , amount) ;
      if(balance_return == 1 )
      printf("withdrawn .\n ");
      else if(balance_return == 0 )
      printf("Insufficient balance . \n");
    }
    else 
    break ;
    
    
  }while(choice != 4) ;
  
  return 0;
}

void showBalance(float *balance_ptr) 
{
  printf("Balance = %f \n" , *balance_ptr );
}
void deposit(float *balance_ptr, float amount)
{
  *balance_ptr = *balance_ptr + amount ; 
}
int withdraw(float *balance_ptr , float amount)
{
  if(amount > *balance_ptr)
  return 0;
  else
  {
    *balance_ptr = *balance_ptr - amount ; 
    return 1 ;
  }
}
