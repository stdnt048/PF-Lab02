#include<stdio.h>

void convertTime(int , int* , int* , int* );
void addedTime(int , int , int* , int* , int*);

int main()
{
	int t_secs , hrs , mins , secs , add_secs ;
	
	int *hrs_ptr , *mins_ptr , *secs_ptr ;
	
	hrs_ptr = &hrs ; 
	mins_ptr = &mins ;
	secs_ptr = &secs ;
	
	printf("Enter the total number of seconds : ");
	scanf("%d", &t_secs);
	
	convertTime(t_secs , hrs_ptr , mins_ptr , secs_ptr);
	printf(" Time : %02d : %02d : %02d ", hrs , mins , secs );
	
	
	printf("Enter the time in secs to add : ");
	scanf("%d",&add_secs);
	
	addedTime( add_secs , t_secs , hrs_ptr , mins_ptr , secs_ptr );
	printf(" Time : %02d : %02d : %02d ", hrs , mins , secs );
		
	return 0;
}

void convertTime(int time , int *hrs_ptr , int *mins_ptr , int *secs_ptr)
{
	int remaining ;
	*hrs_ptr = time / 3600 ;
	remaining = time % 3600 ;
	time = remaining ; 
	*mins_ptr = time / 60 ;
	remaining = time % 60 ;
	time = remaining ;
	*secs_ptr = time ;
}

void addedTime(int time , int added , int *hrs_ptr , int *mins_ptr , int *secs_ptr)
{
	time = time + added ; 
	convertTime( time , hrs_ptr , mins_ptr , secs_ptr);
}




