#include<stdio.h>

void circleInfo(float, float *  , float * );

int main()
{
  float area , circumference ;
  float radius = -1 ;
  float *area_ptr ;
  float *circumference_ptr ;
  
  area_ptr = &area ; 
  circumference_ptr = &circumference ;
  
  
  while( radius < 0 ) 
  {
    printf("Enter the radius : ");
    scanf("%f", &radius );
    if( radius < 0 )
    {
      printf("Radius can not be negative . Enter again  . \n");
    }
    
  }
  
  circleInfo( radius, area_ptr , circumference_ptr );
  
  printf("Area = %f \n Circumference = %f \n" , area , circumference );
  
  return 0;
}

void circleInfo(float radius, float *area_ptr , float *circumference_ptr )
{
  *area_ptr = 3.14159 * radius * radius ;
  *circumference_ptr = 2 * 3.14159 * radius ; 
}
