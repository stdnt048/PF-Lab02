#include<stdio.h>
#include<math.h>

int solveQuadratic(double a, double b, double c, double *r1, double *r2);

int main()
{
	double a , b , c , R1 , R2 , roots ;
	double *r1 , *r2 ;
	
	r1 = &R1 ;
	r2 = &R2 ;
	
	printf("Enter a , b , c : ");
	scanf("%lf %lf %lf" , &a , &b , &c );
	
	roots = solveQuadratic(a , b , c , r1 , r2) ;
	
	if(roots == 2)
	printf("Two roots : %lf %lf ", R1 , R2);
	else if(roots == 1)
	printf("One Root : %lf ",R1);
	else
	printf("No roots .");
	
	
	
	return 0;
}

int solveQuadratic(double a, double b, double c, double *r1, double *r2)
{
	double disc ;
	disc = b*b - (4*a*c) ;
	printf("%d = disc \n ", disc);
	
	if(disc > 0)
	{
		*r1 = (-b + sqrt(b*b - (4*a*c))) / (2*a);
		*r2 = (-b - sqrt(b*b - (4*a*c))) / (2*a);
		return 2;
	}
	
	if(disc == 0)
	{
		*r1 = (-b / (2*a));
		printf("%lf = r1\n",*r1);
		return 1;	
	}

	if(disc < 0)
	{
		return 0;
	}
		
}


